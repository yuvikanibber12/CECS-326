#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <string.h> 
#include <fcntl.h> 
#include <sys/shm.h> 
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <errno.h>

struct CLASS {
    int index;
    int response[10];
};

int slave(int argc, char* argv[]) {

   if (argc < 3) {
        printf("Please provide the correct amount of arguments. [child number] [shared memory segment name].");
    } else {
        printf("Slave begins execution\n");
        
        char* childNumber = argv[0];
         
        int childNumberInt = atoi(childNumber);

        char* sharedMemorySegmentName = argv[1];

        
        const int SIZE = 4096;

        printf("I am child number %s, received shared memory name %s.\n", childNumber, sharedMemorySegmentName);

       
        int shm_fd;
        
        struct CLASS *shm_base;

        
        shm_fd = shm_open(sharedMemorySegmentName, O_CREAT | O_RDWR, 0666);
        if (shm_fd == -1) {
            printf("prod: Shared memory failed: %s\n", strerror(errno));
            
            exit(1);
        }

        
        ftruncate(shm_fd,SIZE);
        
        
        shm_base =  mmap( 0,SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
        
        if (shm_base == MAP_FAILED) {
            printf("prod: Map failed: %s\n", strerror(errno));/* close and shm_unlink */
           
            exit(1);
        }
        
        
        shm_base -> index = childNumberInt;
        shm_base -> response[childNumberInt] = childNumberInt;
        printf("I have written my child number to shared memory.\n");
        
        
        if (munmap(shm_base, SIZE) == -1) {
            printf("prod: Unmap failed: %s\n", strerror(errno));
           
            exit(1);
        }  

        
        if (close(shm_fd) == -1) {
            printf("prod: Close failed: %s\n", strerror(errno));
           
            exit(1);
        }

        printf("Slave closed access to shared memory and terminates\n");
    }

    
    exit(0);
}