#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>

struct CLASS {
    int index;
    int response[10];
};

int main(int argc, char* argv[]) 
{


   if(argc < 3) {
     printf("Please provide the correct amount of arguments. [n child processes] [shared memory segment name].");
  } else {
        printf("Master begins execution\n");

        char* numberOfChildren = argv[1];
        char* sharedMemorySegmentName = argv[2];

        
        const int SIZE = 4096;

        
        struct CLASS *shm_base;

        
        int shm_fd;

        
        shm_fd = shm_open(sharedMemorySegmentName, O_CREAT | O_RDWR, 0666);
        if (shm_fd == -1) {
            printf("prod: Shared memory failed: %s\n", strerror(errno));
            
            exit(1);
        }

        if (shm_base == MAP_FAILED) {
            printf("prod: Map failed: %s\n", strerror(errno));/* close and shm_unlink */
            
            exit(1);
        }

        
        ftruncate(shm_fd, SIZE);

        
        shm_base = mmap(0,SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

        printf("Master created a shared memory segment named %s.\n", sharedMemorySegmentName);

        
        int nChildren = atoi(numberOfChildren);

        for(int i = 0; i < nChildren; i++) {
            
            pid_t cpid = fork();
            
            if (cpid == 0) { 
                char number_str[10];
                
                sprintf(number_str, "%d", i);

                
                char *args[] = {number_str, sharedMemorySegmentName, NULL};

                
                execv("./slave", args);

               
                exit(0);
            }
        }

        printf("Master created %s child processes to execute slave.\n", numberOfChildren);

        printf("Master waits for all child processes to terminate.\n");
        
        while(wait(NULL) != -1);
        
        printf("Master received termination signals from all %s child processes.\n", numberOfChildren);

        printf("Content of shared memory segment filled by child processes:\n");
        printf("--- content of shared memory ---\n");

        for(int i = 0; i < nChildren; i++) {
            printf("%d\n", shm_base -> response[i]);
        }

        
        if (munmap(shm_base, SIZE) == -1) {
            printf("cons: Unmap failed: %s\n", strerror(errno));
            
            exit(1);
        }

        
        if (close(shm_fd) == -1) {
            printf("cons: Close failed: %s\n", strerror(errno));
            
            exit(1);
        }

       
        if (shm_unlink(sharedMemorySegmentName) == -1) {
            printf("cons: Error removing %s: %s\n", sharedMemorySegmentName, strerror(errno));
           
            exit(1);
        }

        printf("Master removed shared memory segment, and is exiting.\n");
    }
    
    exit(0);
}
