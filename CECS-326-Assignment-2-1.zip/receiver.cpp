#include <unistd.h> //system library
#include <sys/wait.h> //wait library
#include <stdio.h> 
#include <stdlib.h>
#include <iostream>
#include <string.h> //string
#include <sys/msg.h> //message queue library

using namespace std;

struct my_msgbuf {
    long mtype;
    char message[50];
};

int receiver(int argc,char* argv[]) {

    if(argc > 0) {
        printf("Receiver, PID %d, begins execution", getpid());

        //message queue id
        int qid;
        // Convert the the message queue id to int.
        sscanf(argv[0], "%d", &qid);

        my_msgbuf msg;
        // Calculate the message size. 
        //size of message buf - size of long variable. 
        int size = sizeof(msg)-sizeof(long);

        printf("\nReceiver received message queue id %d through commandline parameter", qid);

        // Receive the message. 
        msgrcv(qid, (struct my_msgbuf *)&msg, size, 114, 0);

        printf("\nReceiver: retrieved the following message from message queue: \n");
        cout << msg.message << endl;
       // command to terminate. 
        printf("\nReceiver terminates\n");
    }
    //terminate
    return 0;
}