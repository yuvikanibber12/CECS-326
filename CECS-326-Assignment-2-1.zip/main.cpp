#include <sys/types.h>
#include <sys/ipc.h> //IPC library
#include <sys/msg.h> //message queue
#include <string.h> //string
#include <iostream>
#include <unistd.h> //system library
#include <sys/wait.h> //wait library
#include <stdlib.h>

using namespace std;

int main() {
  //begining execution
  printf("Master, PID %d, begins execution", getppid());

    // creating a key for the message. 
    key_t key;
    
    // Creating a message id.
    int qid = msgget(key, IPC_CREAT|0600);
    
    //printing the statement.
    printf("\nMaster acquired a message queue, id %d\n", qid);
    
    //holding the message to use in other programs. 
    char qidNumber[50];
    
    // Create the first child which is sender. 
    pid_t cpid = fork();
    // 0 = fork successful
    if (cpid == 0) { 
        printf("\nMaster created a child process with PID %d to execute sender\n", getpid());
        // Arguments that will be passed to the child program. 
        char *args[] = {qidNumber, NULL};
        // Execute the child program and give it the above arguments.
        execv("./sender", args);

        // Exit the child process.
        exit(0);
    }
    // Create the second child which is the receiver. 
    cpid = fork();
    
    if (cpid == 0) {
        printf("\nMaster created a child process with PID %d to execute receiver\n", getpid());
        // Arguments that will be passed to the child program. 
        char *args[] = {qidNumber, NULL};

        // Execute the child program and give it the above arguments.
        execv("./receiver", args);

        // Exit the child process.
        exit(0);
    }

    printf("\nMaster wait for both child processes to terminate\n");
    // waiting for both children to terminate (wait(NULL))
    while(wait(NULL) != -1);

    // terminates the message queue. 
    msgctl(qid, IPC_RMID, NULL); 
    

    printf("\nMaster received termination signals from both child processes, removed message queue, and terminates\n");
    //terminates the parent process. 
    exit(0);
}